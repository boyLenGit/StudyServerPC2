create view view_goods_sell as
select `mo`.`goods`.`goodsid`             AS `goodsid`,
       `mo`.`goods`.`batchname`           AS `batchname`,
       `mo`.`goods`.`goodsserial`         AS `goodsserial`,
       `mo`.`goods`.`barcode`             AS `barcode`,
       `mo`.`goods`.`goodsname`           AS `goodsname`,
       `mo`.`goods`.`goodstype`           AS `goodstype`,
       `mo`.`goods`.`inputsize`           AS `inputsize`,
       `mo`.`goods`.`quantity`            AS `quantity`,
       `mo`.`goods`.`unitprice`           AS `unitprice`,
       `mo`.`goods`.`totalprice`          AS `totalprice`,
       `mo`.`goods`.`costunitprice`       AS `costunitprice`,
       `mo`.`goods`.`costtotalprice`      AS `costtotalprice`,
       `mo`.`goods`.`userid`              AS `userid`,
       `mo`.`goods`.`createtime`          AS `createtime`,
       avg(`mo`.`goods`.`costunitprice`)  AS `cost_unit_price`,
       sum(`mo`.`goods`.`costtotalprice`) AS `cost_total_price`
from `mo`.`goods`
group by `mo`.`goods`.`barcode`;

