create view view_user as
select `mo`.`user`.`userid`     AS `userid`,
       `mo`.`user`.`username`   AS `username`,
       `mo`.`user`.`password`   AS `password`,
       `mo`.`user`.`realname`   AS `realname`,
       `mo`.`user`.`phone`      AS `phone`,
       `mo`.`user`.`role`       AS `role`,
       `mo`.`user`.`createtime` AS `createtime`
from `mo`.`user`;

