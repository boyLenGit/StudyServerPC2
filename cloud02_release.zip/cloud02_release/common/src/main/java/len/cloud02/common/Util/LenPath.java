package len.cloud02.common.Util;

public class LenPath {
    private static final String data = "/home/mbl/LenData/cloud02";
//    private static final String data = "/Users/mabolun/Project/Java/cloud02/data";

    public static String getData() {
        return data;
    }
}
