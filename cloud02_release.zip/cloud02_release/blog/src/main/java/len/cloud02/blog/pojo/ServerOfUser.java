package len.cloud02.blog.pojo;

public class ServerOfUser {
    private Long id;
    private String ip;
    private String username;
    private String password;

}
