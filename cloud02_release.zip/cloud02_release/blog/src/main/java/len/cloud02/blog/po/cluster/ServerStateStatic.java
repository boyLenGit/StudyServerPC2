package len.cloud02.blog.po.cluster;

public class ServerStateStatic {
    private String ip;
    private String port;
    private String user;
    private String password;

    private String cpu_core_num;
    private String cpu_name;

    private String linux_name;
    private String linux_version;

}
