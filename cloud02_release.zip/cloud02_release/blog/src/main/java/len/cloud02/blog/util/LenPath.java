package len.cloud02.blog.util;

public class LenPath {
//    private static final String data = "/Users/mabolun/Project/Java/cloud02/data";
    private static final String data = "/home/mbl/LenData/cloud02";

    public static String getData() {
        return data;
    }
}
