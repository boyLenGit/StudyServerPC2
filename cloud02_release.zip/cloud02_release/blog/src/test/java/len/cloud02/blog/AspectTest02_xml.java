package len.cloud02.blog;

public class AspectTest02_xml {
}

