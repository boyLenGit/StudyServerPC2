package len.cloud02.blog;

public class testFastJson {
    public static void main(String[] args) {

    }


}
